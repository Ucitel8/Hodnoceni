import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useIsAdmin } from "@/lib/auth";

export function Navbar() {
  const isAdmin = useIsAdmin();

  return (
    <nav className="border-b">
      <div className="container flex items-center h-14">
        {/* Admin Login in the upper left corner */}
        <Link href={isAdmin ? "/admin" : "/login"}>
          <Button variant="ghost" size="sm" className="mr-4">
            {isAdmin ? "Admin Panel" : "Admin Login"}
          </Button>
        </Link>
        
        {/* Title in the center */}
        <div className="flex-1 flex justify-center">
          <Link href="/">
            <Button variant="link" className="text-lg font-semibold">
              Teacher Reviews
            </Button>
          </Link>
        </div>
      </div>
    </nav>
  );
}
